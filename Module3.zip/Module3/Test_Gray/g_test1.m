      %%%%%%%%%%%%%%%%%%%%%%%%%%MODULE 1%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%step1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
k=randi([0,1],16,8);
%load('k1.mat');%test case name
k_d=zeros(16,1);
for i=1:16
    k_d(i)=bi2de(k(i,:),'left-msb');
end

t=zeros(16,1);

        a=(2.75);
        b=(3.4);
    t(1)=(mod((k_d(1)*100)/256,(b-a)*100)/100)+a;
    
        a=(2.75);
        b=(3.45);
    t(2)=(mod((k_d(2)*100)/256,(b-a)*100)/100)+a;
  
  
        a=(0.15);
        b=(0.21);
    t(3)=(mod((k_d(3)*100)/256,(b-a)*100)/100)+a;

        a=(0.13);
        b=(0.15);
    t(4)=(mod((k_d(4)*100)/256,(b-a)*100)/100)+a;
  

u1=t(1);
u2=t(2);
v1=t(3);
v2=t(4);
% fprintf('After step 1\n');
% t

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%step2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tmax=max(k_d(5:16));
tmin=min(k_d(5:16));
tssv=257;
for i=5:16
    if k_d(i)<tssv && k_d(i)~=tmin
        tssv=k_d(i);
    end
end
tmax;
tmin;
tssv;
x0=vpa(tmin/256);
y0=vpa(tssv/256);
qx=vpa(u1*x0*(1-x0)+v1*y0*y0);
qy=vpa(u2*y0*(1-y0)+v2*(x0*x0+x0*y0));
E=zeros(2*ceil(tmax/2),1);
e=0.001;
for i=1:2:(2*ceil(tmax/2))
    
    E(i)=vpa((1-e)*qx+e*qy);
    E(i+1)=vpa((1-e)*qy+e*qx);
    qx=vpa(u1*E(i)*(1-E(i))+v1*E(i+1)*E(i+1));
    qy=vpa(u2*E(i+1)*(1-E(i+1))+v2*(E(i)*E(i)+E(i)*E(i+1)));
end

for i=5:16
    if k_d(i)==0
        t(i)=E(1);
    else
        t(i)=E(k_d(i));
    end
end
% fprintf('After step 2\n');
% t

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%step3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
img = imread('F:\1\IT\VI sem projects\IAS\gray_scale\5.1.09.tiff');
%imshow(img);
figure('Name','Original Image')
imshow(img);
figure
histogram(img)
%img1=rgb2gray(img);
[W,H]=size(img);
a=zeros(3,1);
b=zeros(3,1);
ku=zeros(3,1);
kv=zeros(3,1);
for i=5:7
    a(i-4)=floor((mod(floor(t(i)*W*H),256))/16);
    b(i-4)=mod((mod(floor(t(i)*W*H),256)),16);
end
% a
% b
for i=8:10
    ku(i-7)=mod(floor(t(i)*W*H),256);
end

for i=11:13
    kv(i-10)=mod(floor(t(i)*W*H),256);
end
% fprintf('After step 3\n');
% ku
% kv

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%step4%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% fprintf('After step 4\n');
x0_ = t(14);
y0_ = mod(t(15)*10,1)/10;
z0_=mod(t(15)*10,2)/10;


