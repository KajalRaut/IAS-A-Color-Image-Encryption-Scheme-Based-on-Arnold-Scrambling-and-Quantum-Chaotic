      %%%%%%%%%%%%%%%%%%%%%%%%%%MODULE 2%%%%%%%%%%%%%%%%%%%%%%%%
module1;
N=max(W,H);
R=img(:,:,1);
G=img(:,:,2);
B=img(:,:,3);
if W~=H
    if W>H
        for i=1:N
            for j=H+1:N
                R(i,j)= randi([0,255],1,1);
                G(i,j)= randi([0,255],1,1);
                B(i,j)= randi([0,255],1,1);
            end
        end
    end
    if W<H
        for i=1+W:N
            for j=1:N
                R(i,j)= randi([0,255],1,1);
                G(i,j)= randi([0,255],1,1);
                B(i,j)= randi([0,255],1,1);
            end
        end
    end
end

R;
G;
B;

% new=cat(3,R,G,B);
% figure
% imshow(new);
R_=zeros(N);
B_=zeros(N);
G_=zeros(N);
for i=1:N
    for j=1:N
        A=[1 a(1);b(1) (a(1)*b(1))+1];
        xy=[i;j];
        for ki=1:6
            x_y_=A*(xy+[ku(1);kv(1)]);
            xy=x_y_;
        end
        x_y_=mod(x_y_,N);
        R_(x_y_(1)+1,x_y_(2)+1)=R(i,j);
        
        A=[1 a(2);b(2) (a(2)*b(2))+1];
        xy=[i;j];
        for ki=1:6
            x_y_=A*(xy+[ku(2);kv(2)]);
            xy=x_y_;
        end
        x_y_=mod(x_y_,N);
        G_(x_y_(1)+1,x_y_(2)+1)=G(i,j);
        
        A=[1 a(3);b(3) (a(3)*b(3))+1];
        xy=[i;j];
        for ki=1:6
            x_y_=A*(xy++[ku(3);kv(3)]);
            xy=x_y_;
        end
        x_y_=mod(x_y_,N);
        B_(x_y_(1)+1,x_y_(2)+1)=B(i,j);
            
    end
end
R_;
G_;
B_;
% new2=cat(3,R_,G_,B_);
% figure
% imshow(new2);
%%%%%%%%%%%%%%%%%%%%% step 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%
L=N*N;
m=13;
r=3.99;
Beta=6;
x_=x0_;
y_=y0_;
z_=z0_;
X=zeros(1,1);
Y=zeros(1,1);
Z=zeros(1,1);

for i=1:m+L
    fi2_x=abs(r*(x_ -abs(x0_)^2)-r*y_);
    fi2_y=abs(-1*y_ * exp(-2*Beta)+exp(-Beta)*r*((2*x_-x_)*y_-x_*z_-x_*z_));
    fi2_z=abs(-1*z_ * exp(-2*Beta)+exp(-Beta)*r*(2*(1-x_)*z_-2*y_*x_-x_));
    x1_=mod((1-e)*fi2_x+e*fi2_y,1);
    y1_=mod((1-e)*fi2_y+e*fi2_z,0.1);
    z1_=mod((1-e)*fi2_z+e*fi2_x,0.2);
    X=[X,x1_];
    Y=[Y,y1_];
    Z=[Z,z1_];
    x_=x1_;
    y_=y1_;
    z_=z1_;
   
end
X=sort(X(14:m+L))
Y=sort(Y(14:m+L))
Z=sort(Z(14:m+L))

%%%%%%%%%%%%%%%%%%%%%%%%step 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

R_vec=reshape(R_,1,L);
B_vec=reshape(B_,1,L);
G_vec=reshape(G_,1,L);

%%%%%%%%%%%%%%%%%%%%%%%%%step 3%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cr=zeros(1,L);
Cg=zeros(1,L);
Cb=zeros(1,L);
for i=1:L
        Cr(i)=bitxor(mod(floor(X(i)*W*H*k_d(6)*k_d(7)*k_d(9)*k_d(10)*k_d(12)*k_d(13)),256),R_vec(i));
        Cg(i)=bitxor(mod(floor(Y(i)*W*H*k_d(5)*k_d(7)*k_d(8)*k_d(10)*k_d(11)*k_d(13)),256),G_vec(i));
        Cb(i)=bitxor(mod(floor(Z(i)*W*H*k_d(5)*k_d(6)*k_d(8)*k_d(9)*k_d(11)*k_d(12)),256),B_vec(i));
end
Cr=reshape(Cr,N,N);
Cg=reshape(Cg,N,N);
Cb=reshape(Cb,N,N);
cimage=cat(3,Cr,Cg,Cb);
figure('Name','Cipher Image')
imshow(cimage);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%decryption%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cr=reshape(Cr,1,L);
Cg=reshape(Cg,1,L);
Cb=reshape(Cb,1,L);
Cr_=zeros(1,L);
Cg_=zeros(1,L);
Cb_=zeros(1,L);

for i=1:L
        Cr_(i)=bitxor(mod(floor(X(i)*W*H*k_d(6)*k_d(7)*k_d(9)*k_d(10)*k_d(12)*k_d(13)),256),Cr(i));
        Cg_(i)=bitxor(mod(floor(Y(i)*W*H*k_d(5)*k_d(7)*k_d(8)*k_d(10)*k_d(11)*k_d(13)),256),Cg(i));
        Cb_(i)=bitxor(mod(floor(Z(i)*W*H*k_d(5)*k_d(6)*k_d(8)*k_d(9)*k_d(11)*k_d(12)),256),Cb(i));
end
Rr_=reshape(Cr_,N,N);
Gg_=reshape(Cg_,N,N);
Bb_=reshape(Cb_,N,N);
R2_=zeros(N);
B2_=zeros(N);
G2_=zeros(N);

% cimage=cat(3,Rr_,Gg_,Bb_);
% figure
% imshow(cimage);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% yeyyyyy %%%%%%%%%%%%%%%%%%%%%%
for i=1:N
    for j=1:N
       A=[1 a(1);b(1) (a(1)*b(1))+1];
        xy=[i;j];
        for ki=1:6
            x_y_=A*(xy+[ku(1);kv(1)]);
            xy=x_y_;
        end
        x_y_=mod(x_y_,N);
        R2_(i,j)=Rr_(x_y_(1)+1,x_y_(2)+1);
        
        A=[1 a(2);b(2) (a(2)*b(2))+1];
        xy=[i;j];
        for ki=1:6
            x_y_=A*(xy+[ku(2);kv(2)]);
            xy=x_y_;
        end
        x_y_=mod(x_y_,N);
        G2_(i,j)=Gg_(x_y_(1)+1,x_y_(2)+1);
        
       A=[1 a(3);b(3) (a(3)*b(3))+1];
        xy=[i;j];
        for ki=1:6
            x_y_=A*(xy+[ku(3);kv(3)]);
            xy=x_y_;
        end
        x_y_=mod(x_y_,N);
        B2_(i,j)=Bb_(x_y_(1)+1,x_y_(2)+1);
            
    end
end
R2_=uint8(R2_);
G2_=uint8(G2_);
B2_=uint8(B2_);
pimage=cat(3,R2_,G2_,B2_);
figure('Name','Decrypted Image')
imshow(pimage);

